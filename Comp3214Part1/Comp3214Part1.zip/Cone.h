#pragma once
#include "Mesh.h"
class Cone :
	public Mesh
{
public:
	Cone();
	~Cone();
};

