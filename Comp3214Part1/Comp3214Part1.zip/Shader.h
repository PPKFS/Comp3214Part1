#pragma once
#include <GL/glew.h>
#include <string>
GLuint LoadShader(std::string filename);
GLuint CreateShaderProgram();