print("Config.lua executed")
GLFW = 3
GLew = true
STD = 'c++11'
BOOST = false
BULLET = false
AntTweakBar = false
MODEL = false